# CMG-FILE-UPLOADER

This is a microservice to upload documents in CMG. It exposes all the operations over REST API. Currently only DEO Schedule and Evidence documents can be uploaded.

## Technology stack

The following technologies have been used in this project :-

- Microservice - Spring Boot
- Virus Scaning - SquidClamAV (ClamAV ICAP service for Squid)

Note - The virus scanning is based on a feature toggle and is switched off by default.

## Build

To build the application, run the following command from the root directory :-

```$xslt
mvn clean install
```

This should run unit tests, build the application and build the docker image for the application.

## Profiles to run the application

The following Spring profiles have been provided in the application to run it against different environments :-

- default - To run locally (does not do antivirus scan)
- ssl - To run locally on HTTPS (does not do antivirus scan)
- docker - To run in a docker container (does not do antivirus scan)

## How to run

This microservice can be run against the 3 different profiles (as mentioned above) in one of the following ways :-

### Run locally

You can run the microservice locally in one of the 2 ways below :-

- Running it as a Spring Boot application from your IDE (Eclipde/IntelliJ)

- After building the project, go to the target directory and run the command :- `java -jar cmg-file-uploader-<version>.jar`

### Run locally on HTTPS

You can run the microservice locally over HTTPS in one of the 2 ways below :-

- Running it as a Spring Boot application from your IDE (Eclipde/IntelliJ) and use the spring profile name as `ssl`

- After building the project, go to the target directory and run the command :- `java -jar cmg-file-uploader-<version>.jar -D spring.profiles.active=ssl`

### Run in docker

A docker image of the application is created when you perform the maven build. Run the following commands from the application root directory to bring up the docker container :-

```$xslt
mv .env.example .env
docker-compose up -d
```

## REST API contract and testing

The application will be running on port 8080. Go to `http://localhost:8080/swagger-ui.html` to view the Swagger API contract (use `https` if you are using the `ssl` profile). You can use the Swagger UI to test the API endpoints.


