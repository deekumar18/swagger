package uk.gov.dwp.cmg.file.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.exception.ErrorEnum;
import uk.gov.dwp.cmg.file.model.AntivirusScanResponse;
import uk.gov.dwp.cmg.file.model.CustomerData;
import uk.gov.dwp.cmg.file.model.XmlMetadata;

@Service
@Slf4j
@RequiredArgsConstructor
public class FileService {

	private static final String DATE_FORMAT = "ddMMYYYY";
	private static final String UNDERSCORE = "_";
	private static final String DOT = ".";
	private static final String XML = "xml";
	private static final String ZIP = "zip";
	private static final String XMLNS = "http://www.childmaintenance.gsi.gov.uk/futurescheme/bo/UploadEvidence";

	private final FileValidationService fileValidationService;
	private final AntivirusService antivirusService;
	private final FileStorageService fileStorageService;

	public String validateAndUploadDeoFile(final MultipartFile file, final String ern) {
		// AV scan
		performAntivirusScan(file);

		// Validate
		this.fileValidationService.validateDEOFile(file, ern);

		// Upload
		final String filePath = this.fileStorageService.getDeoFileDirectory();
		this.fileStorageService.store(file, filePath);

		return file.getOriginalFilename();
	}

	public List<String> validateAndUploadEvidenceFile(final List<MultipartFile> files,
			final CustomerData customerData) {

		// Validate duplicate file names
		final List<String> fileNames = files.stream().map(MultipartFile::getOriginalFilename)
				.collect(Collectors.toList());
		this.fileValidationService.validateDuplicateFileNames(fileNames);

		// Validate all files
		files.forEach(file -> {
			// AV scan
			performAntivirusScan(file);

			// Validate
			this.fileValidationService.validateEvidenceFile(file);
		});

		final List<String> filesUploaded = new ArrayList<>();
		final List<XmlMetadata.ListOfAttachments.Attachment> attachments = new ArrayList<>();

		// Create result directory
		final String evidenceFileDirectoryPath = this.fileStorageService
				.createEvidenceFileDirectory(customerData.getScin());
		final String uploadTime = evidenceFileDirectoryPath
				.substring(evidenceFileDirectoryPath.lastIndexOf(UNDERSCORE) + 1);
		final String uploadDate = LocalDate.now().format(DateTimeFormatter.ofPattern(DATE_FORMAT));
		final String metadataFileName = FilenameUtils.getBaseName(evidenceFileDirectoryPath);

		// Create XML metadata
		XmlMetadata xml = createXmlMetadata(metadataFileName, uploadDate.concat(uploadTime), customerData);

		files.forEach(file -> {
			final String fileName = file.getOriginalFilename();
			final String fileBaseName = FilenameUtils.getBaseName(fileName);
			final String fileExtension = FilenameUtils.getExtension(fileName);
			final String encodedFileName = new StringJoiner(DOT).add(DigestUtils.md5Hex(fileBaseName))
					.add(fileExtension).toString();

			// Upload
			this.fileStorageService.store(file, evidenceFileDirectoryPath);

			// Create metadata attachment sections
			attachments.add(XmlMetadata.ListOfAttachments.Attachment.builder().fileName(fileName)
					.encodedFileName(encodedFileName).fileType(fileExtension).fileSize(String.valueOf(file.getSize()))
					.build());

			filesUploaded.add(file.getOriginalFilename());
		});

		// Append to xml metadata
		final XmlMetadata.ListOfAttachments listOfAttachments = XmlMetadata.ListOfAttachments.builder()
				.attachments(attachments).build();
		xml.setFileCount(String.valueOf(attachments.size()));
		xml.setListOfAttachments(listOfAttachments);

		// Write xml
		this.fileStorageService.writeXml(xml, new StringJoiner(DOT).add(metadataFileName).add(XML).toString(),
				evidenceFileDirectoryPath);

		// Zip result directory
		this.fileStorageService.zipDirectory(evidenceFileDirectoryPath);

		// Delete result directory
		this.fileStorageService.deleteDirectory(evidenceFileDirectoryPath);

		return filesUploaded;
	}

	private XmlMetadata createXmlMetadata(final String fileName, final String dateTime,
			final CustomerData customerData) {
		return XmlMetadata.builder().xmlns(XMLNS).batchId(new StringJoiner(DOT).add(fileName).add(ZIP).toString())
				.uploadDateTime(dateTime).scin(customerData.getScin()).firstName(customerData.getFirstName())
				.lastName(customerData.getLastName()).location(customerData.getLocation()).build();
	}

	private void performAntivirusScan(final MultipartFile file) {
		final AntivirusScanResponse avScanResult = this.antivirusService.scan(file);
		if (!avScanResult.isResult()) {
			// AV scan failed
			log.error("Antivirus scan of file {} has failed", file.getOriginalFilename());
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.VIRUS_FOUND);
		}
		log.info("No virus found in file : {}", file.getOriginalFilename());
	}

}
