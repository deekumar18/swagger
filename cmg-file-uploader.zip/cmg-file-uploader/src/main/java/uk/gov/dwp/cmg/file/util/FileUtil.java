package uk.gov.dwp.cmg.file.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FilenameUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import lombok.extern.slf4j.Slf4j;
import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.exception.ErrorEnum;
import uk.gov.dwp.cmg.file.model.DEOSchedule;
import uk.gov.dwp.cmg.file.model.FileType;

@Slf4j
public class FileUtil {

	private static final String[] DEO_FILE_EXTENSIONS = { "csv", "xml" };
	private static final String[] EVIDENCE_FILE_EXTENSIONS = { "pdf", "jpg", "tif", "tiff", "gif", "png", "jpeg" };
	private static final String FILE_NAME_VALID_PATTERN = "[!@#$%&*()_+=|<>?{}\\[\\]~-]";

	private FileUtil() {
		// private constructor for util class
	}

	public static boolean validateFileExtension(final FileType fileType, final String fileName) {
		final String extension = FilenameUtils.getExtension(fileName);
		boolean isValidExtension;
		if (fileType == FileType.DEO) {
			isValidExtension = Arrays.asList(DEO_FILE_EXTENSIONS).contains(extension);
			log.info("Validity of extension for DEO file {} is : {}", fileName, isValidExtension);
			return isValidExtension;
		} else if (fileType == FileType.EVIDENCE) {
			isValidExtension = Arrays.asList(EVIDENCE_FILE_EXTENSIONS).contains(extension);
			log.info("Validity of extension for Evidence file {} is : {}", fileName, isValidExtension);
			return isValidExtension;
		}
		throw new BadRequestException(fileName, ErrorEnum.INVALID_FILE_TYPE);
	}

	public static boolean validateFileName(final String fileName) {
		final Pattern pattern = Pattern.compile(FILE_NAME_VALID_PATTERN);
		final Matcher matcher = pattern.matcher(fileName);
		return !matcher.find();
	}

	public static List<String> getAllLinesFromAFile(final MultipartFile file) {
		final List<String> lines = new ArrayList<>();
		try (final InputStream inputStream = file.getInputStream();
				final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));) {

			String line;
			while ((line = bufferedReader.readLine()) != null) {
				lines.add(line);
			}
		} catch (IOException e) {
			log.error("Error while reading CSV file {}", file.getOriginalFilename(), e);
		}
		return lines;
	}

	public static boolean validateCSVFormat(final List<String> lines) {
		int lineNumber = 0;
		boolean isValid = false;
		for (String line : lines) {
			final int numberOfCommas = StringUtils.countOccurrencesOf(line, ",");
			lineNumber++;
			if ((lineNumber == 1 || lineNumber == 2) && (numberOfCommas == 5 || numberOfCommas == 6)) {
				isValid = true;
			} else if (lineNumber == 3 && numberOfCommas == 6) {
				isValid = true;
			} else if (lineNumber > 3 && numberOfCommas == 6) {
				final String[] lineContents = line.split(",");
				final String scin = lineContents[3];
				final String nino = lineContents[2];
				if (!isSCINNumeric(scin) || !isValidNINO(nino)) {
					return false;
				}
			} else {
				return false;
			}
		}
		return isValid;
	}

	public static boolean validateERNInCSV(final String line, final String ern) {
		final String ernInFile = line.split(",")[2];
		return ern.equalsIgnoreCase(ernInFile);
	}

	public static boolean validateDateRangeInCSV(final String line) {
		final LocalDate today = getLocalDate();
		final LocalDate actualFromDate = today.minusMonths(1);
		final LocalDate actualToDate = today.plusMonths(1);

		final String[] parts = line.split(",");
		final String getPaymentFrom = parts[3];
		final String getPaymentTo = parts[4];
		return isValidDateRange(actualFromDate, actualToDate, getPaymentFrom, getPaymentTo);
	}

	private static boolean isValidDateRange(final LocalDate actualFromDate, final LocalDate actualToDate,
			final String getPaymentFrom, final String getPaymentTo) {
		final LocalDate paymentFromDate = LocalDate.parse(getPaymentFrom, DateTimeFormatter.BASIC_ISO_DATE);
		log.info("Payment From Date : {}", paymentFromDate);

		final LocalDate paymentToDate = LocalDate.parse(getPaymentTo, DateTimeFormatter.BASIC_ISO_DATE);
		log.info("Payment To Date : {}", paymentToDate);

		return actualFromDate.isBefore(paymentFromDate) && actualToDate.isAfter(paymentToDate);
	}

	public static boolean validateERNInXML(final DEOSchedule deoSchedule, final String ern) {
		return ern.equalsIgnoreCase(deoSchedule.getCompanyLevelInfo().getEmployerRefNumber());
	}

	public static boolean validateDateRangeInXML(final DEOSchedule deoSchedule) {
		final LocalDate today = getLocalDate();
		final LocalDate actualFromDate = today.minusMonths(1);
		final LocalDate actualToDate = today.plusMonths(1);

		final String paymentFrom = deoSchedule.getCompanyLevelInfo().getPaymentFromDate();
		final String paymentTo = deoSchedule.getCompanyLevelInfo().getPaymentToDate();
		return isValidDateRange(actualFromDate, actualToDate, paymentFrom, paymentTo);
	}

	public static DEOSchedule getDEOFromXml(final MultipartFile file) throws IOException {
		final StringBuilder builder = new StringBuilder();
		getAllLinesFromAFile(file).stream().forEachOrdered(builder::append);
		final String xmlString = builder.toString();
		final XmlMapper mapper = new XmlMapper();
		return mapper.readValue(xmlString, DEOSchedule.class);
	}

	public static boolean isFileExists(final MultipartFile fileToScan, final String directory) {
		final Path filePath = Paths.get(directory.concat(File.separator).concat(fileToScan.getOriginalFilename()));
		return filePath.toFile().exists();
	}

	public static boolean validateFileSize(final FileType fileType, final MultipartFile file, final long maxSize) {
		if (file.getSize() > maxSize) {
			return false;
		}
		return !(fileType == FileType.EVIDENCE && file.getOriginalFilename().length() > 100);
	}

	private static LocalDate getLocalDate() {
		return LocalDate.now();
	}

	private static boolean isSCINNumeric(final String scin) {
		if (scin == null) {
			return false;
		}
		return scin.matches("[0-9]+");
	}

	private static boolean isValidNINO(final String nino) {
		if (nino == null) {
			return false;
		}
		String number = ".*[0-9].*";
		String alpha = ".*[A-Z].*";
		return nino.matches(number) && nino.matches(alpha);
	}

}
