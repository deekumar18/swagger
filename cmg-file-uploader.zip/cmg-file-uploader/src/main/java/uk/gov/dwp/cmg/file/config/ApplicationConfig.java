package uk.gov.dwp.cmg.file.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import uk.gov.dwp.cmg.file.icap.ICAPConnection;
import uk.gov.dwp.cmg.file.icap.ICAPProperties;
import uk.gov.dwp.cmg.file.model.AntivirusScanResponse;
import uk.gov.dwp.cmg.file.service.AntivirusService;
import uk.gov.dwp.cmg.file.service.ICAPScanner;

@Configuration
public class ApplicationConfig {

	@Bean
	@ConditionalOnProperty(name = "icap.enabled", havingValue = "true")
	public ICAPConnection icapConnection(final ICAPProperties icapProperties) {
		return new ICAPConnection(icapProperties.getServerAddress(), icapProperties.getServerPort(),
				icapProperties.getServiceName(), true);
	}

	@Bean
	@ConditionalOnBean(ICAPConnection.class)
	public AntivirusService icapService(final ICAPConnection icapConnection) {
		return new ICAPScanner(icapConnection);
	}

	@Bean
	@ConditionalOnProperty(name = "icap.enabled", havingValue = "false")
	public AntivirusService antivirusService() {
		return file -> AntivirusScanResponse.builder().result(true).code("0").build();
	}
}
