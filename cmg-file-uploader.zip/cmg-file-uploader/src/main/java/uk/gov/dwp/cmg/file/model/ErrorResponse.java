package uk.gov.dwp.cmg.file.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "Error response", description = "The error response")
public class ErrorResponse {

	@ApiModelProperty(value = "The error file name", required = true)
	private String fileName;

	@ApiModelProperty(value = "The error description", required = true)
	private String error;

}
