package uk.gov.dwp.cmg.file.model;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JacksonXmlRootElement(localName = "DEOSchedule", namespace = "http://www.childmaintenance.gsi.gov.uk/futurescheme/bo/CMECDEOSchedule")
public class DEOSchedule {

	@JacksonXmlProperty(localName = "CompanyLevelInfo")
	private CompanyLevelInfo companyLevelInfo;

	@JacksonXmlProperty(localName = "EmployeeLevelInformation")
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<EmployeeLevelInfo> employeeLevelInfo;

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class CompanyLevelInfo {

		@JacksonXmlProperty(localName = "EmployerName")
		protected String employerName;

		@JacksonXmlProperty(localName = "EmpPAYERef")
		protected String employerPAYERef;

		@JacksonXmlProperty(localName = "EmployerRefNum")
		protected String employerRefNumber;

		@JacksonXmlProperty(localName = "PaymentFromDte")
		protected String paymentFromDate;

		@JacksonXmlProperty(localName = "PaymentToDte")
		protected String paymentToDate;

		@JacksonXmlProperty(localName = "TotalAmountPaid")
		protected String totalAmount;

	}

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class EmployeeLevelInfo {

		@JacksonXmlProperty(localName = "Forename")
		protected String forename;

		@JacksonXmlProperty(localName = "Surname")
		protected String surname;

		@JacksonXmlProperty(localName = "NINO")
		protected String nino;

		@JacksonXmlProperty(localName = "MonthlyAmtDue")
		protected String monthlyAmountDue;

		@JacksonXmlProperty(localName = "AmountPaid")
		protected String amountPaid;
	}
}
