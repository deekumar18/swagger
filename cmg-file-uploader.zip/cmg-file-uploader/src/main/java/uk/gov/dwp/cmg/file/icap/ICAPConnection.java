package uk.gov.dwp.cmg.file.icap;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
public class ICAPConnection {

	private static final String NEWLINE = "\r\n\r\n";

	private String serverAddress;
	private int serverPort;
	private String serviceName;
	private String optionsString;
	private int socketReadTimeout;
	private int previewBytes;
	private SSLSocket socket;
	private BufferedReader input;
	private DataOutputStream output;
	private boolean isConnected;
	private boolean isDebugMode;

	public ICAPConnection(final String serverAddress, final int serverPort, final String serviceName,
			final boolean isDebugMode) {
		this.serverAddress = serverAddress;
		this.serverPort = serverPort;
		this.serviceName = serviceName;
		this.optionsString = setOptionsString(serverAddress, serverPort, serviceName);
		this.isDebugMode = isDebugMode;

		this.socketReadTimeout = 60000;
		this.previewBytes = 30;
	}

	private String setOptionsString(final String serverAddress, final int serverPort, final String serviceName) {
		StringBuilder stringBuilder = new StringBuilder("OPTIONS icap://");
		stringBuilder.append(serverAddress);
		stringBuilder.append(":");
		stringBuilder.append(serverPort);
		stringBuilder.append("/");
		stringBuilder.append(serviceName);
		stringBuilder.append("?profile=default");
		stringBuilder.append(" ICAP/1.0\r\nHost: ");
		stringBuilder.append(serverAddress);
		stringBuilder.append(NEWLINE);
		return stringBuilder.toString();
	}

	public void disconnect() {
		try {
			if (this.input != null) {
				this.input.close();
			}
			if (this.output != null) {
				this.output.close();
			}
			if (!this.socket.isClosed()) {
				this.socket.close();
			}
			this.socket = null;
			this.input = null;
			this.output = null;
			this.isConnected = false;

			log.info("ICAP connection closed");
		} catch (final Exception e) {
			this.isConnected = false;
			log.error("Error while disconnecting ICAP connection", e);
		}
		log.info("ICAPConnection:disconnect() - end of method");
	}

	public void connect() {
		if (this.socket == null) {

			try {
				SSLSocketFactory socketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();

				this.socket = (SSLSocket) socketFactory.createSocket(InetAddress.getByName(this.serverAddress),
						this.serverPort);

				this.socket.setSoTimeout(this.socketReadTimeout);
				this.output = new DataOutputStream(this.socket.getOutputStream());

				this.input = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
				this.isConnected = true;
				if (this.isDebugMode) {
					optionsCheck();
				}
			} catch (Exception e) {
				this.isConnected = false;
				log.error("Error while making ICAP connection", e);
			}
		}
	}

	private String optionsCheck() {
		String returnString;
		if (this.isConnected) {
			if (sendData(this.optionsString) > -1) {
				returnString = receiveData();
				log.info("Response from ICAP in options check : {} ", returnString);
			} else {
				returnString = "Error:C99:optionsCheck:send:" + this.optionsString;
			}
		} else {
			returnString = "Error:C99:optionsCheck:connectionerror:" + this.serverAddress + ":" + this.serverPort;
		}
		return this.optionsString + returnString;
	}

	public String receiveData() {
		String returnString = "";
		if (this.isConnected) {
			String value = "  ";
			String[] results = new String[1024];
			int arrayLocation = 0;
			try {
				while (value.length() != 0) {
					value = this.input.readLine();
					returnString = returnString + value + "\n";
					results[arrayLocation] = value;
					arrayLocation++;
				}
			} catch (Exception e) {
				log.error("Error while receiving data from ICAP", e);
				returnString = "Error:C99:receiveData():" + e;
			}
		} else {
			log.error("Error - no ICAP connection available");
			returnString = "Error:C99:receive():notconnected";
		}
		return returnString;
	}

	public int sendData(final String str) {
		int retValue = 0;

		if (this.isConnected) {
			try {
				this.output.writeBytes(str);
				this.output.flush();
			} catch (Exception e) {
				log.error("Error in sending data : {}", str, e);
				retValue = -1;
			}
		} else {
			log.error("ICAPConnection:sendData() - no connection available");
			retValue = -1;
		}
		return retValue;
	}

	public int sendByte(final byte[] b, final int start, final int length) {
		int retValue = 0;

		if (this.isConnected) {
			try {
				this.output.write(b, start, length);
				this.output.writeBytes("\r\n0\r\n\r\n");
				this.output.flush();
			} catch (Exception e) {
				log.error("Error in sending bytes", e);
				retValue = -1;
			}
		} else {
			log.error("Error - no ICAP connection available");
			retValue = -1;
		}
		return retValue;
	}

	public String getRequestHeader(final String fileName, final String timestamp, final String clientIP) {
		String encodedFileName = "";
		try {
			encodedFileName = fileName.substring(
					URLEncoder.encode(fileName, StandardCharsets.UTF_8.toString()).lastIndexOf(File.separator) + 1);
		} catch (final UnsupportedEncodingException e) {
			log.error("Error while encoding file : {}", fileName, e);
		}
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("GET http://");
		stringBuilder.append(clientIP);
		stringBuilder.append("/");
		stringBuilder.append(timestamp);
		stringBuilder.append("/");
		stringBuilder.append(encodedFileName);
		stringBuilder.append(" HTTP/1.1\r\nHost: ");
		stringBuilder.append(clientIP);
		stringBuilder.append(NEWLINE);
		return stringBuilder.toString();
	}

	public String createICAPRequestHeader(final long req_header_length, final long res_header_length,
			final long res_body_length, String clientIP) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("RESPMOD icap://");
		stringBuilder.append(this.serverAddress);
		stringBuilder.append(":");
		stringBuilder.append(this.serverPort);
		stringBuilder.append("/");
		stringBuilder.append(this.serviceName);
		stringBuilder.append("?profile=default");
		stringBuilder.append(" ICAP/1.0\r\nAllow: 204\r\nEncapsulated: req-hdr=");
		stringBuilder.append(req_header_length);
		stringBuilder.append(" res-hdr=");
		stringBuilder.append(res_header_length);
		stringBuilder.append(" res-body=");
		stringBuilder.append(res_body_length);
		stringBuilder.append("\r\nHost: ");
		stringBuilder.append(this.serverAddress);
		stringBuilder.append("\r\nPreview: ");
		stringBuilder.append(this.previewBytes);
		stringBuilder.append("\r\nUser-Agent: JavaICAPClient\r\nX-Client-IP: ");
		stringBuilder.append(clientIP);
		stringBuilder.append(NEWLINE);

		return stringBuilder.toString();
	}
}
