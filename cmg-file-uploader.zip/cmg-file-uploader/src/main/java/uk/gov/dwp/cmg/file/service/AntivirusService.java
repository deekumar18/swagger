package uk.gov.dwp.cmg.file.service;

import org.springframework.web.multipart.MultipartFile;

import uk.gov.dwp.cmg.file.model.AntivirusScanResponse;

public interface AntivirusService {

	AntivirusScanResponse scan(final MultipartFile file);

}
