package uk.gov.dwp.cmg.file.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.security.SignatureException;
import io.jsonwebtoken.security.WeakKeyException;
import lombok.extern.slf4j.Slf4j;

/**
 * @author samba.mitra
 */
@Slf4j
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	public static final String HEADER_SECURITY_TOKEN = "Authorization";

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Override
	protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain filterChain) throws ServletException, IOException {
		final String token = request.getHeader(HEADER_SECURITY_TOKEN);
		String username = null;
		if (token != null && token.startsWith("Bearer ")) {
			final String jwtToken = token.substring(7);
			try {
				username = this.jwtTokenUtil.getUsernameFromToken(jwtToken);
				SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(username, null, null));
			} catch (final WeakKeyException e) {
				log.error("Key size not secure enough", e);
				// TODO : Remove next line when strong JWT secret has been created
				SecurityContextHolder.getContext().setAuthentication(new JwtAuthenticationToken(username, null, null));
			} catch (final SignatureException e) {
				log.error("Unable to verify JWT signature", e);
			} catch (final IllegalArgumentException e) {
				log.error("Unable to get JWT token", e);
			} catch (final ExpiredJwtException e) {
				log.error("JWT token has expired", e);
			}
		} else {
			log.error("JWT Token does not begin with Bearer String");
		}
		filterChain.doFilter(request, response);
	}

	@Override
	protected boolean shouldNotFilter(final HttpServletRequest request) throws ServletException {
		final String path = request.getRequestURI();
		return !path
				.startsWith(ApiSecurityConfig.API_MATCHER.substring(0, ApiSecurityConfig.API_MATCHER.lastIndexOf('/')));
	}
}