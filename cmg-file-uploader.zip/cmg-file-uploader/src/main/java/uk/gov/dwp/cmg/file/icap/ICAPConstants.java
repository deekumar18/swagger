package uk.gov.dwp.cmg.file.icap;

public class ICAPConstants {

	private ICAPConstants() {
		// Private constructor
	}

	public static final String PROFILE_NAME = "?profile=default";

	public static final String RESPONSE_HEADER = "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n";

	public static final String OPTIONS_URL_STR = "OPTIONS icap://";

	public static final String GET_URL_STR = "GET http://";

	public static final String RESPMOD_URL_STR = "RESPMOD icap://";

	public static final String ICAP_HOST_URL_STR = " ICAP/1.0\r\nHost: ";

	public static final String HTTP_HOST_URL_STR = " HTTP/1.1\r\nHost: ";

	public static final String ICAP_HEADER_STR1 = " ICAP/1.0\r\nAllow: 204\r\nEncapsulated: req-hdr=";

	public static final String ICAP_RES_HEADER_LENGTH_STR1 = " res-hdr=";

	public static final String ICAP_RES_BODY_LENGTH_STR1 = " res-body=";

	public static final String HOST_STR = "\r\nHost: ";

	public static final String PREVIEW_STR = "\r\nPreview: ";

	public static final String CLIENT_IP_STR = "\r\nUser-Agent: JavaICAPClient\r\nX-Client-IP: ";

	public static final String END_CHAR_SEQ1_STR = "\r\n\r\n";

	public static final String END_BYTE_SEQ1_STR = "\r\n0\r\n\r\n";

	public static final String SEPARATOR_STRING = "/";

	public static final String COLON_STRING = ":";

	public static final String SCAN_RESPONSE_SCAN_SUCCESS_CODE = "0";

	public static final String SCAN_RESPONSE_SCAN_SUCCESS_DESC = "Clean: Scan successful";

	public static final String VALIDATION_RESPONSE_SCAN_SUCCESS_CODE = "0";

	public static final String VALIDATION_RESPONSE_SCAN_SUCCESS_DESC = "Validation successful";

	public static final String VALIDATION_RESPONSE_INVALID_NULL_FILENAME_CODE = "C24";

	public static final String VALIDATION_RESPONSE_INVALID_NULL_FILENAME_DESC = "Error: invalid or null filename";

	public static final String VALIDATION_RESPONSE_INVALID_SIZE_CODE = "C25";

	public static final String VALIDATION_RESPONSE_INVALID_SIZE_DESC = "Error: invalid or null size";

	public static final String TRANSFER_RESPONSE_SCAN_SUCCESS_CODE = "0";

	public static final String TRANSFER_RESPONSE_SCAN_SUCCESS_DESC = "File transfer successful";

	public static final String SCAN_RESPONSE_SCAN_FAILIURE_CODE = "C999";

	public static final String SCAN_RESPONSE_SCAN_FAILIURE_DESC = "Stop: Check the response from MWG";

	public static final String SCAN_RESPONSE_TOO_MANY_FILES_CODE = "E23";

	public static final String SCAN_RESPONSE_TOO_MANY_FILES_DESC = "Error: TOO_MANY_FILES";

	public static final String SCAN_RESPONSE_NOT_MULTIPART_CODE = "C11";

	public static final String SCAN_RESPONSE_NOT_MULTIPART_DESC = "Error: Not a multipart request";

	public static final String SCAN_RESPONSE_INVALID_CHAR_IN_FILENAME_CODE = "C23";

	public static final String SCAN_RESPONSE_INVALID_CHAR_IN_FILENAME_DESC = "Error: invalid char in filename/Max file name length limit";

	public static final String SCAN_RESPONSE_INVALID_FILETYPE_CODE = "22";

	public static final String SCAN_RESPONSE_INVALID_FILETYPE_DESC = "Error: invalid file type";

	public static final String SCAN_RESPONSE_INVALID_FILE_MIN_SIZE_CODE = "C22";

	public static final String SCAN_RESPONSE_INVALID_FILE_MIN_SIZE_DESC = "Error: invalid file - size is less the 1 byte";

	public static final String SCAN_RESPONSE_INVALID_FILE_MAX_SIZE_CODE = "C33";

	public static final String SCAN_RESPONSE_INVALID_FILE_MAX_SIZE_DESC = "Error: invalid file - size exceeded allowed limit";

	public static final String SCAN_RESPONSE_FAILED_SCAN_OR_UPLOAD_CODE = "C99";

	public static final String SCAN_RESPONSE_FAILED_SCAN_OR_UPLOAD_DESC = "Error: File transfer failiure or Exception";

	public static final String SCAN_RESPONSE_FORBIDDEN_CODE = "C99";

	public static final String SCAN_RESPONSE_FORBIDDEN_DESC = "Error: User not logged in to perform the action";

	public static final String TRANSFER_RESPONSE_SCAN_FAIL_DUPLICATE_CODE = "C71";

	public static final String TRANSFER_RESPONSE_SCAN_FAIL_DUPLICATE_DESC = "Can not transfer, already named file exists";

	public static final String TRANSFER_RESPONSE_SCAN_FAIL_SERVICE_CODE = "C70";

	public static final String TRANSFER_RESPONSE_SCAN_FAIL_SERVICE_DESC = "File transfer service failiured, see logs";
}
