package uk.gov.dwp.cmg.file.icap;

import lombok.extern.slf4j.Slf4j;
import uk.gov.dwp.cmg.file.model.AntivirusScanResponse;

@Slf4j
public class ICAPUtil {

	public boolean isPreviewScanSuccessful(final String serverResponse) {
		String response = serverResponse;
		if (serverResponse.length() != 12) {
			response = serverResponse.substring(0, 12);
		}
		return response.startsWith("ICAP/1.0 100");
	}

	public String parseServerResponse(final String serverResponse) {
		String status = "Undefined";
		String blockResult = "";
		String virusName = ";";
		String[] lines = serverResponse.split("\n");

		for (int i = 0; i < lines.length; i++) {
			if (lines[i].startsWith("ICAP/1.0 204")) {
				status = "Clean:";
				blockResult = "0";
				virusName = "No malware detected;";
				break;
			}
			if (lines[i].startsWith("ICAP/1.0 200")) {
				status = "Blocked:";
				blockResult = "200";

			} else if (lines[i].startsWith("X-Virus-Name:")) {
				status = "Infected:";

				if (lines[i].substring(14).startsWith(virusName.substring(0, virusName.length() - 1))) {
					virusName = lines[i].substring(14);
				} else {
					virusName = virusName + lines[i].substring(14);
				}
				virusName = virusName + ";";

			} else if (lines[i].startsWith("X-WWBlockResult:")) {
				blockResult = lines[i].substring(17);
				switch (Integer.parseInt(blockResult)) {
				case 90:
					virusName = virusName + "Policy:Unwanted Unsigned Content;";
					break;
				case 81:
					virusName = virusName + "Policy:Authorization needed;";
					break;
				case 45:
					virusName = virusName + "Policy:Macros unwanted;";
					break;
				case 44:
					virusName = virusName + "Policy:Office document unreadable;";
					break;
				case 43:
					virusName = virusName + "Policy:Encrypted document unwanted;";
					break;
				case 42:
					virusName = virusName + "Policy:ActiveX unwanted;";
					break;
				case 41:
					virusName = virusName + "Policy:Document Inspector;";
					break;
				case 40:
					virusName = virusName + "Policy:Text Categorization unwanted;";
					break;
				case 34:
					virusName = virusName + "Policy:Encrypted archive unwanted;";
					break;
				case 33:
					virusName = virusName + "Policy:Archive recursion level exceeded;";
					break;
				case 32:
					virusName = virusName + "Policy:Mailbomb unwanted;";
					break;
				case 31:
					virusName = virusName + "Policy:Corrupted archive unwanted;";
					break;
				case 30:
					virusName = virusName + "Policy:Multipart archive unwanted;";
					break;
				case 23:
					virusName = virusName + "Policy:Generic Body Filter;";
					break;
				case 22:
					virusName = virusName + "Policy:Media type blacklisted;";
					break;
				case 21:
					virusName = virusName + "Policy:Media type mismatch;";
					break;
				default:
					status = "Infected:";
					break;
				}

			} else if (lines[i].startsWith("ICAP/1.0 ")) {
				status = "Error:" + lines[i];
			}
		}
		if (virusName.endsWith(";")) {
			virusName = virusName.substring(0, virusName.length() - 1);
		}
		if ("".equals(virusName.trim())) {
			virusName = "Unknown";
		}
		return status + blockResult + ":\"" + virusName + "\"";
	}

	public AntivirusScanResponse getResultCode(final String scanResult) {
		String code;
		boolean result = false;
		if (scanResult == null || "".equals(scanResult.trim())) {
			log.error("Not a valid error code {}", scanResult);
			code = "C99";
		} else if (scanResult.startsWith("Clean")) {
			log.info("Clean file, sending success ");
			result = true;
			code = "0";
		} else if (scanResult.startsWith("Error") || scanResult.startsWith("Undefined") || "".equals(scanResult)) {
			log.error("Error response obtained {}, so parsing error code", scanResult);
			code = getErrorCodeFromResult(scanResult);
		} else if (scanResult.startsWith("Blocked")) {
			log.error("Blocked response obtained {}, so parsing error code", scanResult);
			code = getErrorCodeFromResult(scanResult);
		} else if (scanResult.startsWith("Infected")) {
			log.error("Infected file with error response {}, so sending wrapper error code : C55", scanResult);
			code = "C55";
		} else {
			log.error("Unknown response {}", scanResult);
			code = "C99";
		}

		return AntivirusScanResponse.builder().result(result).code(code).build();
	}

	private String getErrorCodeFromResult(String returnString) {
		String code = null;
		if (returnString.contains(":")) {
			try {
				String[] responses = returnString.split(":", 3);
				code = responses[1];
			} catch (final Exception e) {
				log.error("Error in getting error code from result {}", returnString, e);
				code = "C99";
			}
		}
		return code;
	}
}
