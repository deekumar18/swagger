package uk.gov.dwp.cmg.file.icap;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Configuration
@ConfigurationProperties(prefix = "icap")
@Data
public class ICAPProperties {

	private String serverAddress;
	private int serverPort;
	private String serviceName;

}
