package uk.gov.dwp.cmg.file.exception;

public class BusinessException extends RuntimeException {

	private static final long serialVersionUID = 2714362864860297840L;

	public BusinessException(final ErrorEnum error) {
		super(error.getError());
	}

}
