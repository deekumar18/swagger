package uk.gov.dwp.cmg.file.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.util.StringJoiner;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import uk.gov.dwp.cmg.file.config.FileProperties;
import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.exception.BusinessException;
import uk.gov.dwp.cmg.file.exception.ErrorEnum;
import uk.gov.dwp.cmg.file.model.XmlMetadata;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileStorageService {

	private final FileProperties fileProperties;

	public boolean store(final MultipartFile file, final String path) {
		final String filePath = new StringJoiner(File.separator).add(path).add(file.getOriginalFilename()).toString();
		try {
			Files.createFile(Paths.get(filePath));
			log.info("Uploaded file : {}", filePath);
			return true;
		} catch (FileAlreadyExistsException e) {
			log.error("File already exists : {}", filePath);
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.ALREADY_EXISTS);
		} catch (IOException e) {
			log.error("Cannot create file {}", filePath);
			throw new BusinessException(ErrorEnum.FILE_WRITE_PROBLEM);
		}
	}

	public String createEvidenceFileDirectory(final String scin) {
		final String folderName = new StringJoiner("_").add(scin).add(LocalTime.now().toString()).toString()
				.replace(":", "");
		final String resultDirectoryName = folderName.substring(0, folderName.indexOf('.'));
		final String directoryPath = new StringJoiner(File.separator)
				.add(this.fileProperties.getEvidence().getLocation()).add(resultDirectoryName).toString();
		try {
			Files.createDirectories(Paths.get(directoryPath));
			log.info("Result directory created : {}", directoryPath);
			return directoryPath;
		} catch (IOException e) {
			log.error("Cannot create directory {}", directoryPath);
			throw new BusinessException(ErrorEnum.FILE_WRITE_PROBLEM);
		}
	}

	public String getDeoFileDirectory() {
		return this.fileProperties.getDeo().getLocation();
	}

	public boolean writeXml(final XmlMetadata xml, final String fileName, final String path) {
		final XmlMapper xmlMapper = new XmlMapper();
		xmlMapper.enable(SerializationFeature.INDENT_OUTPUT);
		xmlMapper.configure(ToXmlGenerator.Feature.WRITE_XML_DECLARATION, true);
		final String filePath = new StringJoiner(File.separator).add(path).add(fileName).toString();
		try {
			xmlMapper.writeValue(new File(filePath), xml);
			log.info("XML file written : {}", filePath);
			return true;
		} catch (IOException e) {
			log.error("Cannot create XML file {}", filePath, e);
			throw new BusinessException(ErrorEnum.FILE_WRITE_PROBLEM);
		}
	}

	public boolean zipDirectory(final String sourceDirectoryPath) {
		final String zipFileName = FilenameUtils.getBaseName(sourceDirectoryPath).concat(".").concat("zip");
		final String zipFilePath = new StringJoiner(File.separator).add(this.fileProperties.getEvidence().getLocation())
				.add(zipFileName).toString();
		final Path sourcePath = Paths.get(sourceDirectoryPath);
		try (ZipOutputStream zipOutputStream = new ZipOutputStream(Files.newOutputStream(Paths.get(zipFilePath)));
				Stream<Path> pathStream = Files.walk(sourcePath)) {
			pathStream.filter(path -> !path.toFile().isDirectory()).forEach(path -> {
				final ZipEntry zipEntry = new ZipEntry(sourcePath.relativize(path).toString());
				try {
					zipOutputStream.putNextEntry(zipEntry);
					Files.copy(path, zipOutputStream);
					zipOutputStream.closeEntry();
				} catch (IOException e) {
					log.error("Cannot create ZIP file {}", zipFilePath, e);
					throw new BusinessException(ErrorEnum.FILE_WRITE_PROBLEM);
				}
			});
			return true;
		} catch (IOException e) {
			log.error("Cannot create output stream for zip file path {}", zipFilePath, e);
			throw new BusinessException(ErrorEnum.TECHNICAL_PROBLEM);
		}
	}

	public boolean deleteDirectory(final String directoryPath) {
		try {
			FileUtils.deleteDirectory(new File(directoryPath));
			return true;
		} catch (IOException e) {
			log.error("Cannot delete directory {}", directoryPath, e);
			throw new BusinessException(ErrorEnum.TECHNICAL_PROBLEM);
		}
	}
}
