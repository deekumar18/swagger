package uk.gov.dwp.cmg.file.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@JacksonXmlRootElement(localName = "UploadEvidence")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class XmlMetadata {

	@JacksonXmlProperty(localName = "xmlns", isAttribute = true)
	private String xmlns;

	@JacksonXmlProperty(localName = "BatchID")
	private String batchId;

	@JacksonXmlProperty(localName = "UploadDateTime")
	private String uploadDateTime;

	@JacksonXmlProperty(localName = "SCIN")
	private String scin;

	@JacksonXmlProperty(localName = "FirstName")
	private String firstName;

	@JacksonXmlProperty(localName = "LastName")
	private String lastName;

	@JacksonXmlProperty(localName = "Location")
	private String location;

	@JacksonXmlProperty(localName = "FileCount")
	@Setter
	private String fileCount;

	@JacksonXmlProperty(localName = "ListOfAttachments")
	@Setter
	protected ListOfAttachments listOfAttachments;

	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ListOfAttachments {

		@JacksonXmlProperty(localName = "Attachments")
		@JacksonXmlElementWrapper(useWrapping = false)
		protected List<Attachment> attachments;

		@Data
		@Builder
		@NoArgsConstructor
		@AllArgsConstructor
		@JsonInclude(JsonInclude.Include.NON_NULL)
		public static class Attachment {

			@JacksonXmlProperty(localName = "FileName")
			protected String fileName;

			@JacksonXmlProperty(localName = "EncodedFileName")
			protected String encodedFileName;

			@JacksonXmlProperty(localName = "FileType")
			protected String fileType;

			@JacksonXmlProperty(localName = "FileSize")
			protected String fileSize;
		}
	}

}
