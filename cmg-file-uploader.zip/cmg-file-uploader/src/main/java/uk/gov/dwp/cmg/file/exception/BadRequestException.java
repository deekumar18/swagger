package uk.gov.dwp.cmg.file.exception;

public class BadRequestException extends RuntimeException {

	private static final long serialVersionUID = 2714362864860297840L;

	private final String fileName;

	public BadRequestException(final String fileName, final ErrorEnum error) {
		super(error.getError());
		this.fileName = fileName;
	}

	public String getFileName() {
		return this.fileName;
	}

}
