package uk.gov.dwp.cmg.file.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "File upload response", description = "The file upload response")
public class FileUploadResponse {

	@ApiModelProperty(value = "The names of the files uploaded", required = true)
	private List<String> fileNames;
}
