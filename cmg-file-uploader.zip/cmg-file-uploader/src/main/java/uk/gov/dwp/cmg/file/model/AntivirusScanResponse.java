package uk.gov.dwp.cmg.file.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AntivirusScanResponse {
	private boolean result;
	private String code;
}
