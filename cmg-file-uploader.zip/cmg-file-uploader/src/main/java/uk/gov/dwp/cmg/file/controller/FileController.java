package uk.gov.dwp.cmg.file.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.SwaggerDefinition;
import io.swagger.annotations.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import uk.gov.dwp.cmg.file.model.CustomerData;
import uk.gov.dwp.cmg.file.model.ErrorResponse;
import uk.gov.dwp.cmg.file.model.FileUploadResponse;
import uk.gov.dwp.cmg.file.service.FileService;

@RestController
@RequestMapping(value = "/api/files", produces = APPLICATION_JSON_VALUE)
@Api(tags = { "API Operations" })
@SwaggerDefinition(tags = {
		@Tag(name = "API Operations", description = "File upload/download in Child Maintenance Service") }, produces = APPLICATION_JSON_VALUE, consumes = MULTIPART_FORM_DATA_VALUE)
@Slf4j
@RequiredArgsConstructor
public class FileController {

	private final FileService fileService;

	@PostMapping("/deo")
	@ResponseStatus(HttpStatus.CREATED)
	@ApiOperation(value = "Upload a DEO file", notes = "This endpoint uploads a DEO (Deductions from Earning Order) file. It checks the selected file for virus and business validations and uploads if the validations pass.", response = FileUploadResponse.class)
	@ApiImplicitParam(name = "Authorization", value = "JWT Bearer Token", required = true, dataTypeClass = String.class, paramType = "header")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "File uploaded successfully"),
			@ApiResponse(code = 400, message = "Bad request", response = ErrorResponse.class),
			@ApiResponse(code = 401, message = "Unauthorized"),
			@ApiResponse(code = 500, message = "Error while processing the request", response = ErrorResponse.class) })
	public ResponseEntity<FileUploadResponse> uploadDEOFile(
			@ApiParam(value = "File to upload", required = true) @RequestPart("file") @Valid @NotNull @NotBlank final MultipartFile file,
			@ApiParam(value = "The Employee Reference Number", required = true) @RequestParam("ern") @NotBlank final String ern) {

		final String fileUploaded = this.fileService.validateAndUploadDeoFile(file, ern);

		return new ResponseEntity<>(FileUploadResponse.builder().fileNames(Arrays.asList(fileUploaded)).build(),
				HttpStatus.CREATED);
	}

	@PostMapping("/evidence")
	@ResponseStatus(HttpStatus.CREATED)
	@ApiOperation(value = "Upload one or more Evidence files", notes = "This endpoint uploads one or more Evidence files. It checks each selected file for virus and business validations and uploads the files only if all of them pass validation. This API returns an error even if one file fails validation.", response = FileUploadResponse.class)
	@ApiImplicitParam(name = "Authorization", value = "JWT Bearer Token", required = true, dataTypeClass = String.class, paramType = "header")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "File(s) uploaded successfully"),
			@ApiResponse(code = 400, message = "Bad request", response = ErrorResponse.class),
			@ApiResponse(code = 401, message = "Unauthorized"),
			@ApiResponse(code = 500, message = "Error while processing the request", response = ErrorResponse.class) })
	public ResponseEntity<FileUploadResponse> uploadEvidenceFiles(
			@ApiParam(value = "Files to upload", required = true) @RequestPart("files") @Valid @NotNull @NotBlank final MultipartFile[] files,
			@ApiParam(value = "The customer SCIN", required = true) @RequestParam("scin") @NotBlank final String scin,
			@ApiParam(value = "The customer firstName", required = true) @RequestParam("firstName") @NotBlank final String firstName,
			@ApiParam(value = "The customer lastName", required = true) @RequestParam("lastName") @NotBlank final String lastName,
			@ApiParam(value = "The customer location", required = true) @RequestParam("location") @NotBlank final String location) {

		final CustomerData customerData = CustomerData.builder().scin(scin).firstName(firstName).lastName(lastName)
				.location(location).build();
		final List<String> filesUploaded = this.fileService
				.validateAndUploadEvidenceFile(Arrays.stream(files).collect(Collectors.toList()), customerData);

		return new ResponseEntity<>(FileUploadResponse.builder().fileNames(filesUploaded).build(), HttpStatus.CREATED);
	}

}