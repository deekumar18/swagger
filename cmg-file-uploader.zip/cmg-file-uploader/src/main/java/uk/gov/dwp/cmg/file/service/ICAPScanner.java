package uk.gov.dwp.cmg.file.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import uk.gov.dwp.cmg.file.exception.BusinessException;
import uk.gov.dwp.cmg.file.exception.ErrorEnum;
import uk.gov.dwp.cmg.file.icap.ICAPConnection;
import uk.gov.dwp.cmg.file.icap.ICAPUtil;
import uk.gov.dwp.cmg.file.model.AntivirusScanResponse;

@Slf4j
@RequiredArgsConstructor
public class ICAPScanner implements AntivirusService {

	private static final String CLIENT_IP = "localhost";
	private final SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");

	private final ICAPConnection icapConnection;

	@Override
	public AntivirusScanResponse scan(final MultipartFile file) {
		final String fileName = file.getOriginalFilename();
		final byte[] fileBytes;
		try {
			fileBytes = file.getBytes();
		} catch (IOException e) {
			log.error("Error while obtaining bytes from file {}", file.getOriginalFilename(), e);
			throw new BusinessException(ErrorEnum.TECHNICAL_PROBLEM);
		}
		long fileSize = file.getSize();

		// Connect to ICAP
		this.icapConnection.connect();
		log.info("ICAP connection status : {}", this.icapConnection.isConnected());

		int retValue = 0;
		String serverResponse = "";

		int previewBytes = this.icapConnection.getPreviewBytes();

		if (fileSize < previewBytes) {
			log.info("File length {} is smaller than preview bytes {}, but proceeding", fileSize, previewBytes);
			previewBytes = (int) fileSize;
		}

		ICAPUtil icapResponse = new ICAPUtil();

		int reqHeaderLength = 0;
		String requestHeader = this.icapConnection.getRequestHeader(fileName, this.dateTimeFormat.format(new Date()),
				CLIENT_IP);

		int resHeaderLength = requestHeader.length();
		int resBodyLength = resHeaderLength + "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n".length();

		String icapRequest = this.icapConnection.createICAPRequestHeader(reqHeaderLength, resHeaderLength,
				resBodyLength, CLIENT_IP);

		retValue = this.icapConnection.sendData(icapRequest);
		log.debug("Sending icapRequest.. :{}", retValue);
		if (retValue != -1) {
			retValue = this.icapConnection.sendData(requestHeader);
			log.debug("Sending requestHeader.. :{}", retValue);
			if (retValue != -1) {
				retValue = this.icapConnection.sendData("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n");
				log.debug("Sending responseHeader.. :{}", retValue);
				if (retValue != -1) {
					log.debug("Starting preview scan.. ");
					try {
						icapRequest = Long.toHexString(previewBytes);
						retValue = this.icapConnection.sendData(icapRequest);
						log.debug("Preview scan response..{}", retValue);
						if (retValue == -1) {
							return icapResponse.getResultCode(serverResponse);
						}
						retValue = this.icapConnection.sendData("\r\n");
						if (retValue == -1) {
							return icapResponse.getResultCode(serverResponse);
						}
						log.debug("Sending bytes for preview scan..");
						this.icapConnection.sendByte(fileBytes, 0, previewBytes);
						log.debug("Preview scan complete..");
					} catch (Exception e) {
						log.error("Error while doing preview scan", e);
					}
					icapRequest = this.icapConnection.receiveData();
					log.info("Preview scan response for bytes :{}", icapRequest);
					if (icapResponse.isPreviewScanSuccessful(icapRequest)) {
						log.debug("Preview scan success, scan rest of the file..");
						fileSize -= previewBytes;
						try {
							icapRequest = Long.toHexString(fileSize);
							retValue = this.icapConnection.sendData(String.valueOf(icapRequest) + "\r\n");
							if (retValue == -1) {
								return icapResponse.getResultCode(serverResponse);
							}
							log.debug("Sending full bytes for scan..");
							retValue = this.icapConnection.sendByte(fileBytes, previewBytes, (int) fileSize);
							if (retValue == -1) {
								return icapResponse.getResultCode(serverResponse);
							}
							icapRequest = this.icapConnection.receiveData();
							serverResponse = icapResponse.parseServerResponse(icapRequest);
							log.info("Scan rest of the file..serverResponse : {}", serverResponse);
						} catch (Exception e) {
							log.error("Error while doing full scan", e);
						}
					} else {
						log.info("Preview bytes made a determination already..serverResponse : {}", serverResponse);
						serverResponse = icapResponse.parseServerResponse(icapRequest);
					}
					this.icapConnection.disconnect();
				}
			}
		}
		log.info("ICAPScannerImpl:scanFile() - end of method");
		return icapResponse.getResultCode(serverResponse);
	}

}
