package uk.gov.dwp.cmg.file.security;

import java.util.Collection;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

/**
 * @author samba.mitra
 */
public class JwtAuthenticationToken extends AbstractAuthenticationToken { //NOSONAR

	private static final long serialVersionUID = 1L;

	private final transient Object principal;

	public JwtAuthenticationToken(final Object principal) {
		super(null);
		this.principal = principal;
	}

	public JwtAuthenticationToken(final Object principal, final Object details,
			final Collection<? extends GrantedAuthority> authorities) {
		super(authorities);
		this.principal = principal;
		super.setDetails(details);
		super.setAuthenticated(true);
	}

	@Override
	public Object getCredentials() {
		return "";
	}

	@Override
	public Object getPrincipal() {
		return principal;
	}
}
