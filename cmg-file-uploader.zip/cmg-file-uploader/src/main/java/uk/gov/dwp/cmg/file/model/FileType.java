package uk.gov.dwp.cmg.file.model;

public enum FileType {
	DEO, EVIDENCE, UNKNOWN;
}
