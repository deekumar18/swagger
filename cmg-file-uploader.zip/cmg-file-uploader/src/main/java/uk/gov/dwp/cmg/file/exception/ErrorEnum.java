package uk.gov.dwp.cmg.file.exception;

public enum ErrorEnum {

	INVALID_EXTENSION("File has invalid extension"), INVALID_SPECIAL_CHARACTER(
			"File contains invalid character(s)"), INVALID_MAX_SIZE("File size exceeds max limit"), INVALID_ERN(
					"Invalid ERN"), INVALID_DATE_RANGE("Invalid date range or data format"), ALREADY_EXISTS(
							"File already exists"), DUPLICATE_FILE("Duplicate File"), INVALID_FORMAT(
									"File is in wrong format"), INVALID_FILE_TYPE("File type is invalid"), VIRUS_FOUND(
											"File contains virus"), FILE_WRITE_PROBLEM(
													"Error while writing file or directory"), TECHNICAL_PROBLEM(
															"Technical problem");

	private final String error;

	private ErrorEnum(final String error) {
		this.error = error;
	}

	public String getError() {
		return this.error;
	}

}
