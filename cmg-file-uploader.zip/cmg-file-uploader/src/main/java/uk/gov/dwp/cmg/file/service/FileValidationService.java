package uk.gov.dwp.cmg.file.service;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import uk.gov.dwp.cmg.file.config.FileProperties;
import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.exception.ErrorEnum;
import uk.gov.dwp.cmg.file.model.DEOSchedule;
import uk.gov.dwp.cmg.file.model.FileType;
import uk.gov.dwp.cmg.file.util.FileUtil;

@Service
@RequiredArgsConstructor
@Slf4j
public class FileValidationService {

	private static final String CSV = "csv";
	private static final String XML = "xml";

	private final FileProperties fileProperties;

	public boolean validateEvidenceFile(final MultipartFile file) {
		final String fileName = file.getOriginalFilename();

		if (!FileUtil.validateFileExtension(FileType.EVIDENCE, fileName)) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_EXTENSION);
		}

		if (!FileUtil.validateFileSize(FileType.EVIDENCE, file, this.fileProperties.getEvidence().getSize())) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_MAX_SIZE);
		}

		return true;
	}

	public boolean validateDEOFile(final MultipartFile file, final String ern) {
		final String fileName = file.getOriginalFilename();
		final String extension = FilenameUtils.getExtension(fileName);

		if (!FileUtil.validateFileExtension(FileType.DEO, fileName)) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_EXTENSION);
		}

		if (!FileUtil.validateFileName(fileName)) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_SPECIAL_CHARACTER);
		}

		if (!FileUtil.validateFileSize(FileType.DEO, file, this.fileProperties.getDeo().getSize())) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_MAX_SIZE);
		}

		if (FileUtil.isFileExists(file, this.fileProperties.getDeo().getLocation())) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.ALREADY_EXISTS);
		}

		if (CSV.equalsIgnoreCase(extension)) {
			return validateCSVFile(file, ern);
		} else if (XML.equalsIgnoreCase(extension)) {
			return validateXMLFile(file, ern);
		}

		return false;
	}

	private boolean validateCSVFile(final MultipartFile file, final String ern) {
		final List<String> linesInCsvFile = FileUtil.getAllLinesFromAFile(file);
		if (linesInCsvFile.isEmpty()) {
			log.error("No lines present in the CSV file {}", file.getOriginalFilename());
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_FORMAT);
		}

		final String companyLevelInfo = linesInCsvFile.get(1);

		if (!FileUtil.validateCSVFormat(linesInCsvFile)) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_FORMAT);
		}

		if (!FileUtil.validateERNInCSV(companyLevelInfo, ern)) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_ERN);
		}

		if (!FileUtil.validateDateRangeInCSV(companyLevelInfo)) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_DATE_RANGE);
		}

		return true;
	}

	private boolean validateXMLFile(final MultipartFile file, final String ern) {
		final DEOSchedule deoSchedule;
		try {
			deoSchedule = FileUtil.getDEOFromXml(file);
		} catch (final IOException e) {
			log.error("Error while deserializing XML file {}", file.getOriginalFilename(), e);
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_FORMAT);
		}

		if (!FileUtil.validateERNInXML(deoSchedule, ern)) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_ERN);
		}

		if (!FileUtil.validateDateRangeInXML(deoSchedule)) {
			throw new BadRequestException(file.getOriginalFilename(), ErrorEnum.INVALID_DATE_RANGE);
		}

		return true;
	}

	public boolean validateDuplicateFileNames(final List<String> fileNames) {
		final Set<String> set = new HashSet<>();
		for (String fileName : fileNames) {
			if (!set.add(fileName)) {
				throw new BadRequestException(fileName, ErrorEnum.DUPLICATE_FILE);
			}
		}
		return false;
	}
}
