package uk.gov.dwp.cmg.file.controller.advice;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;

import lombok.extern.slf4j.Slf4j;
import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.exception.BusinessException;
import uk.gov.dwp.cmg.file.exception.ErrorEnum;
import uk.gov.dwp.cmg.file.model.ErrorResponse;

@ControllerAdvice(annotations = { RestController.class })
@Slf4j
public class ExceptionHandlingControllerAdvice {

	@ExceptionHandler(BadRequestException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ResponseEntity<ErrorResponse> handleBusinessException(final BadRequestException badRequestException) {
		log.error("Bad request : {}", badRequestException.getMessage(), badRequestException);
		return new ResponseEntity<>(ErrorResponse.builder().fileName(badRequestException.getFileName())
				.error(badRequestException.getMessage()).build(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(BusinessException.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<ErrorResponse> handleTechnicalException(final BusinessException businessException) {
		log.error("Error while processing the request", businessException);
		return new ResponseEntity<>(ErrorResponse.builder().error(businessException.getMessage()).build(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ MultipartException.class, MaxUploadSizeExceededException.class })
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ResponseEntity<ErrorResponse> handleMaxSizeExceededException(final MaxUploadSizeExceededException ex) {
		log.error("Maximum size exceeded", ex);
		return new ResponseEntity<>(ErrorResponse.builder().error(ErrorEnum.INVALID_MAX_SIZE.getError()).build(),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Throwable.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public ResponseEntity<ErrorResponse> handleControllerException(final HttpServletRequest req, final Throwable ex) {
		log.error("Error while processing the request", ex);
		return new ResponseEntity<>(ErrorResponse.builder().error(ex.getMessage()).build(),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "Bad request")
	public ResponseEntity<ErrorResponse> handleJsonPropertyException(final HttpServletRequest req,
			final HttpMessageNotReadableException ex) {
		log.error("Bad request", ex);
		return new ResponseEntity<>(ErrorResponse.builder().error(ex.getMessage()).build(), HttpStatus.BAD_REQUEST);
	}

}
