package uk.gov.dwp.cmg.file.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;

import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.model.AntivirusScanResponse;
import uk.gov.dwp.cmg.file.model.CustomerData;

@RunWith(MockitoJUnitRunner.class)
public class FileServiceTest {

	@Mock
	private FileValidationService fileValidationService;

	@Mock
	private AntivirusService antivirusService;

	@Mock
	private FileStorageService fileStorageService;

	@Mock
	private MultipartFile file;

	@InjectMocks
	private FileService fileService;

	@Test
	public void shouldValidateAndUploadDEOFile() throws IOException {
		// Given
		given(this.antivirusService.scan(file))
				.willReturn(AntivirusScanResponse.builder().result(true).code("0").build());
		given(this.fileValidationService.validateDEOFile(ArgumentMatchers.any(MultipartFile.class),
				ArgumentMatchers.anyString())).willReturn(true);
		given(this.file.getOriginalFilename()).willReturn("filename");
		given(this.fileStorageService.getDeoFileDirectory()).willReturn("path");

		// When
		final String fileName = this.fileService.validateAndUploadDeoFile(file, "1111111111");

		// Then
		assertEquals("Filename not as expected", "filename", fileName);
	}

	@Test
	public void shouldValidateAndUploadEvidenceFile() throws IOException {
		// Given
		final CustomerData customerData = CustomerData.builder().scin("121004201724").build();
		given(this.antivirusService.scan(file))
				.willReturn(AntivirusScanResponse.builder().result(true).code("0").build());
		given(this.fileValidationService.validateEvidenceFile(any(MultipartFile.class))).willReturn(true);
		given(this.file.getOriginalFilename()).willReturn("filename");
		given(this.fileStorageService.createEvidenceFileDirectory(anyString())).willReturn("parent/dir_path");

		// When
		final List<String> fileNames = this.fileService.validateAndUploadEvidenceFile(Arrays.asList(file),
				customerData);

		// Then
		assertEquals("Filenames should have one value", 1, fileNames.size());
		assertEquals("Filename not as expected", "filename", fileNames.get(0));
		verify(this.fileStorageService, times(1)).store(file, "parent/dir_path");
	}

	@Test(expected = BadRequestException.class)
	public void shouldThrowBusinessExceptionIfAntivirusScanFails() throws IOException {
		given(this.antivirusService.scan(file))
				.willReturn(AntivirusScanResponse.builder().result(false).code("C55").build());
		given(this.file.getOriginalFilename()).willReturn("filename");
		this.fileService.validateAndUploadDeoFile(file, null);
		verifyNoMoreInteractions(this.fileValidationService);
	}
}
