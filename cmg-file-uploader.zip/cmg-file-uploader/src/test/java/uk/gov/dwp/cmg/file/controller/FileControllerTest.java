package uk.gov.dwp.cmg.file.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.multipart.MultipartFile;

import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.exception.ErrorEnum;
import uk.gov.dwp.cmg.file.model.CustomerData;
import uk.gov.dwp.cmg.file.service.FileService;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class FileControllerTest {

	private static final String API_BASE_URI = "/api/files/";
	private static final String MULTIPART_NAME = "file";
	private static final String TEXT_PLAIN = "text/plain";
	private static final String MULTIPART_FILE_NAME = "file.csv";
	private static final String TEST_TEXT = "text file content";
	private static final String DEO_URI = API_BASE_URI + "deo";
	private static final String EVIDENCE_URI = API_BASE_URI + "evidence";
	private static final String ERN_PARAM = "ern";
	private static final String ERN = "501001820636";
	private static final String SCIN_PARAM = "scin";
	private static final String SCIN = "501001820636";
	private static final String FIRST_NAME_PARAM = "firstName";
	private static final String FIRST_NAME = "First Name";
	private static final String LAST_NAME_PARAM = "lastName";
	private static final String LAST_NAME = "Last Name";
	private static final String LOCATION_PARAM = "location";
	private static final String LOCATION = "GB Self Service Message";

	private static final String JWT_TOKEN = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiQ0xJRU5UIiwianRpIjoibnpUV0gyWVpnUTlTcHlGdzdmREtFIiwic3ViIjoiMTIxMDA0NjgyOTgzIiwiaWF0IjoxNTY2MzkxMTkzLCJleHAiOjM2MDAxNTY2MzkxMTkzLCJzY29wZSI6Im9wZW5pZCBvZmZsaW5lX2FjY2VzcyIsImlzcyI6Imh0dHBzOi8vbG9jYWxob3N0OjMwMDEvaWFtLWxhcy1kaS9wdWJsaWMvcHJvdmlkZXIiLCJhdWQiOlsiY21nLWxvY2FsLWF1dGgtY2xpZW50LXByb3h5IiwiY21nLW9ubGluZS1wb3J0YWwiLCJjbWctc29hcC1yZXN0LWdhdGV3YXkiLCJjbWctZmlsZS11cGxvYWRlciJdLCJhenAiOiJjbWctbG9jYWwtYXV0aC1jbGllbnQtcHJveHkifQ.PMTCdTmfPc_cTcyYXZuxNhQvqsu0DgRAZz1AZCEwLTE";

	@MockBean
	private FileService fileService;

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testSuccessfulUploadForDEO() throws Exception {
		given(this.fileService.validateAndUploadDeoFile(any(MultipartFile.class), anyString()))
				.willReturn(MULTIPART_FILE_NAME);
		final MockMultipartFile file = new MockMultipartFile(MULTIPART_NAME, MULTIPART_FILE_NAME, TEXT_PLAIN,
				TEST_TEXT.getBytes());

		this.mockMvc.perform(multipart(DEO_URI).file(MULTIPART_NAME, file.getBytes()).param(ERN_PARAM, ERN)
				.header("Authorization", JWT_TOKEN)).andDo(print()).andExpect(status().isCreated());

	}

	@Test
	public void testUnsuccessfulUploadForDEO() throws Exception {
		given(this.fileService.validateAndUploadDeoFile(any(MultipartFile.class), anyString()))
				.willThrow(new BadRequestException("filename", ErrorEnum.ALREADY_EXISTS));
		final MockMultipartFile file = new MockMultipartFile(MULTIPART_NAME, MULTIPART_FILE_NAME, TEXT_PLAIN,
				TEST_TEXT.getBytes());

		this.mockMvc.perform(multipart(DEO_URI).file(MULTIPART_NAME, file.getBytes()).param(ERN_PARAM, ERN)
				.header("Authorization", JWT_TOKEN)).andDo(print()).andExpect(status().isBadRequest());

	}

	@Test
	public void testSuccessfulUploadForEvidence() throws Exception {
		given(this.fileService.validateAndUploadEvidenceFile(any(List.class), any(CustomerData.class)))
				.willReturn(Arrays.asList(MULTIPART_FILE_NAME));
		final MockMultipartFile file = new MockMultipartFile(MULTIPART_NAME, MULTIPART_FILE_NAME, TEXT_PLAIN,
				TEST_TEXT.getBytes());

		this.mockMvc
				.perform(multipart(EVIDENCE_URI).file(MULTIPART_NAME, file.getBytes()).param(SCIN_PARAM, SCIN)
						.param(FIRST_NAME_PARAM, FIRST_NAME).param(LAST_NAME_PARAM, LAST_NAME)
						.param(LOCATION_PARAM, LOCATION).header("Authorization", JWT_TOKEN))
				.andDo(print()).andExpect(status().isCreated());

	}

}
