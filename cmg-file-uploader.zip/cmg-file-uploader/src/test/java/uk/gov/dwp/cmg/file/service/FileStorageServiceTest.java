package uk.gov.dwp.cmg.file.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;

import java.io.File;
import java.io.IOException;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;

import uk.gov.dwp.cmg.file.config.FileProperties;
import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.model.XmlMetadata;

@RunWith(MockitoJUnitRunner.class)
public class FileStorageServiceTest {

	@Mock
	private FileProperties fileProperties;

	@Mock
	private FileProperties.FileDetails fileDetails;

	@Mock
	private MultipartFile file;

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@InjectMocks
	private FileStorageService fileStorageService;

	@Test
	public void shouldStoreDEOFile() {
		// Given
		given(this.file.getOriginalFilename()).willReturn("filename");
		final String folderPath = this.tempFolder.getRoot().getPath();

		// When
		final boolean fileCreated = this.fileStorageService.store(file, folderPath);

		// Then
		assertTrue("DEO File should be created", fileCreated);
	}

	@Test
	public void shouldStoreEvidenceFile() {
		// Given
		given(this.file.getOriginalFilename()).willReturn("filename");
		final String folderPath = this.tempFolder.getRoot().getPath();

		// When
		final boolean fileCreated = this.fileStorageService.store(file, folderPath);

		// Then
		assertTrue("Evidence File should be created", fileCreated);
	}

	// @Test
	// public void shouldThrowExceptionIfFileCannotBeStored() {
	// given(this.file.getOriginalFilename()).willReturn("filename");
	// expectedException.expect(BusinessException.class);
	// expectedException.expectMessage(ErrorEnum.FILE_WRITE_PROBLEM.getError());
	// this.fileStorageService.store(this.file, "non-existent-path");
	// }

	@Test
	public void shouldCreateEvidenceDirectory() {
		// Given
		final String directoryPath = this.tempFolder.getRoot().getPath();
		given(this.fileProperties.getEvidence()).willReturn(this.fileDetails);
		given(this.fileProperties.getEvidence().getLocation()).willReturn(directoryPath);

		// When
		final String evidenceDirectoryPath = this.fileStorageService.createEvidenceFileDirectory("12345");

		// Then
		assertNotNull("Evidence directory should be created", evidenceDirectoryPath);
		final String evidenceDirParent = evidenceDirectoryPath.substring(0,
				evidenceDirectoryPath.lastIndexOf(File.separator));
		assertEquals("Evidence directory path not as expected", directoryPath, evidenceDirParent);
		final String evidenceDirName = evidenceDirectoryPath
				.substring(evidenceDirectoryPath.lastIndexOf(File.separator) + 1);
		final String scinInEvidenceDirName = evidenceDirName.substring(0, evidenceDirName.indexOf("_"));
		assertEquals("SCIN in evidence directory name not as expected", "12345", scinInEvidenceDirName);
	}

	// @Test
	// public void shouldThrowExceptionIfEvidenceDirectoryCannotBeCreated() {
	// given(this.fileProperties.getEvidence()).willReturn(this.fileDetails);
	// given(this.fileProperties.getEvidence().getLocation()).willReturn("non-existent-path");
	// expectedException.expect(BusinessException.class);
	// expectedException.expectMessage(ErrorEnum.FILE_WRITE_PROBLEM.getError());
	// this.fileStorageService.createEvidenceFileDirectory("12345");
	// }

	@Test(expected = BadRequestException.class)
	public void shouldThrowBusinessExceptionIfFileAlreadyExists() {
		given(this.file.getOriginalFilename()).willReturn("filename");
		final String folderPath = this.tempFolder.getRoot().getPath();

		this.fileStorageService.store(file, folderPath);
		this.fileStorageService.store(file, folderPath);
	}

	@Test
	public void testDeoFilePath() {
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getLocation()).willReturn("path");
		final String deoPath = this.fileStorageService.getDeoFileDirectory();
		assertEquals("File path not as expected", "path", deoPath);
	}

	@Test
	public void shouldWriteXml() {
		// Given
		final String fileName = "filename";
		final String filePath = this.tempFolder.getRoot().getPath();
		final XmlMetadata xml = XmlMetadata.builder().scin("1234567890").build();

		// When
		final boolean fileWritten = this.fileStorageService.writeXml(xml, fileName, filePath);

		// Then
		assertTrue("XML file should be written", fileWritten);
	}

	@Test
	public void shouldZipDirectory() throws IOException {
		// Given
		final String directoryPath = this.tempFolder.getRoot().getPath();
		this.tempFolder.getRoot().createNewFile();
		given(this.fileProperties.getEvidence()).willReturn(this.fileDetails);
		given(this.fileProperties.getEvidence().getLocation()).willReturn(directoryPath);

		// When
		boolean zipCreated = this.fileStorageService.zipDirectory(directoryPath);

		// Then
		assertTrue("ZIP should be created", zipCreated);
	}

	@Test
	public void shouldDeleteDirectory() {
		// Given
		final String directoryPath = this.tempFolder.getRoot().getPath();

		// When
		final boolean isDeleted = this.fileStorageService.deleteDirectory(directoryPath);

		// Then
		assertTrue("Directory should be deleted", isDeleted);
	}
}
