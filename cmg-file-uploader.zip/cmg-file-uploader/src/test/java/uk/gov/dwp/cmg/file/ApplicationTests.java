package uk.gov.dwp.cmg.file;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public final class ApplicationTests {

	@Test
	public void contextLoads() { // NOSONAR
		// Context Loading
	}

}
