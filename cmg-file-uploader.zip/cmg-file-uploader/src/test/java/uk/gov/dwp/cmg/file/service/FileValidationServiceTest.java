package uk.gov.dwp.cmg.file.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.multipart.MultipartFile;

import uk.gov.dwp.cmg.file.config.FileProperties;
import uk.gov.dwp.cmg.file.exception.BadRequestException;
import uk.gov.dwp.cmg.file.exception.ErrorEnum;

@RunWith(MockitoJUnitRunner.class)
public class FileValidationServiceTest {

	private static final String INVALID_FILENAME_EXTENSION = "filename.doc";
	private static final String VALID_EVIDENCE_FILENAME = "filename.jpg";
	private static final String INVALID_EVIDENCE_FILENAME_SIZE = "filenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilename.jpg";
	private static final String INVALID_ERN = "ABCDE12345";
	private static final String VALID_DEO_FILENAME_CSV = "filename.csv";
	private static final String VALID_DEO_FILENAME_XML = "filename.xml";
	private static final String INVALID_DEO_FILENAME_CSV = "file@name.csv";

	@Mock
	private FileProperties fileProperties;

	@Mock
	private FileProperties.FileDetails fileDetails;

	@Mock
	private MultipartFile file;

	@InjectMocks
	private FileValidationService fileValidationService;

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	@Test
	public void validateEvidenceFileShouldFailIfFileHasInvalidExtension() {
		given(this.file.getOriginalFilename()).willReturn(INVALID_FILENAME_EXTENSION);
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_EXTENSION.getError());
		this.fileValidationService.validateEvidenceFile(this.file);
	}

	@Test
	public void validateEvidenceFileShouldFailIfFileHasInvalidFileSize() {
		given(this.file.getOriginalFilename()).willReturn(VALID_EVIDENCE_FILENAME);
		given(this.file.getSize()).willReturn(500L);
		given(this.fileProperties.getEvidence()).willReturn(this.fileDetails);
		given(this.fileProperties.getEvidence().getSize()).willReturn(100L);
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_MAX_SIZE.getError());
		this.fileValidationService.validateEvidenceFile(this.file);
	}

	@Test
	public void validateEvidenceFileShouldFailIfFileHasInvalidFilenameSize() {
		given(this.file.getOriginalFilename()).willReturn(INVALID_EVIDENCE_FILENAME_SIZE);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getEvidence()).willReturn(this.fileDetails);
		given(this.fileProperties.getEvidence().getSize()).willReturn(200L);
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_MAX_SIZE.getError());
		this.fileValidationService.validateEvidenceFile(this.file);
	}

	@Test
	public void validateEvidenceFileShouldPassIfFileIsValid() {
		// Given
		given(this.file.getOriginalFilename()).willReturn(VALID_EVIDENCE_FILENAME);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getEvidence()).willReturn(this.fileDetails);
		given(this.fileProperties.getEvidence().getSize()).willReturn(200L);

		// When
		final boolean isValid = this.fileValidationService.validateEvidenceFile(this.file);

		// Then
		assertTrue("Evidence file should be valid", isValid);
	}

	@Test
	public void validateDeoFileShouldFailIfFileHasInvalidExtension() {
		given(this.file.getOriginalFilename()).willReturn(INVALID_FILENAME_EXTENSION);
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_EXTENSION.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFilenameHasSpecialCharacters() {
		given(this.file.getOriginalFilename()).willReturn(INVALID_DEO_FILENAME_CSV);
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_SPECIAL_CHARACTER.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileHasInvalidFileSize() {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(500L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(100L);
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_MAX_SIZE.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileAlreadyExists() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		this.tempFolder.newFile("filename.csv");
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.ALREADY_EXISTS.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsCSVAndIsEmpty() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String csvContents = "";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(csvContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_FORMAT.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsCSVAndHas2RowsAndDoesNotContainValidCommas() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String csvContents = "Comp,PAYE,ERN,Payfrom,Payto,Total,\n"
				+ "AA Insurance,9016693624A,501002000000,20190907,20190910,305.61,,";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(csvContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_FORMAT.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsCSVAndHasMoreThan2RowsAndDoesNotContainValidCommas()
			throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String csvContents = "Comp,PAYE,ERN,Payfrom,Payto,Total,\n"
				+ "Employer For CR1974b14,59196752119,501002028165,20190706,20190805,370,\n"
				+ "Firstname,Surname,NI,PIDNST,AmountDue,ActualAmount,Reason\n"
				+ "Bob,SmithBMJA,LG259220A,121004245393,34,34,45,\n" + "Bob,SmithBMLL,LG259850A,121004245579,32,32,";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(csvContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_FORMAT.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsCSVAndHasMoreThan2RowsAndContainsAlphanumericSCIN()
			throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String csvContents = "Comp,PAYE,ERN,Payfrom,Payto,Total,\n"
				+ "Employer For CR1974b14,59196752119,501002028165,20190706,20190805,370,\n"
				+ "Firstname,Surname,NI,PIDNST,AmountDue,ActualAmount,Reason\n"
				+ "Bob,SmithBMJA,LG259220A,121004245393,34,34,45\n" + "Bob,SmithBMLL,LG259850A,1210042B5579,32,32";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(csvContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_FORMAT.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsCSVAndHasMoreThan2RowsAndContainsInvalidNino() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String csvContents = "Comp,PAYE,ERN,Payfrom,Payto,Total,\n"
				+ "Employer For CR1974b14,59196752119,501002028165,20190706,20190805,370,\n"
				+ "Firstname,Surname,NI,PIDNST,AmountDue,ActualAmount,Reason\n"
				+ "Bob,SmithBMJA,LG2$9220A,121004245393,34,34,45\n" + "Bob,SmithBMLL,LG259850A,12100425579,32,32";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(csvContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_FORMAT.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsCSVAndHasIncorrectERN() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String csvContents = "Comp,PAYE,ERN,Payfrom,Payto,Total,\n"
				+ "AA Insurance,9016693624A,501002000000,20190907,20190910,305.61,";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(csvContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_ERN.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsCSVAndHasIncorrectDateRange() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String csvContents = "Comp,PAYE,ERN,Payfrom,Payto,Total,\n"
				+ "AA Insurance,9016693624A,501002000000,20180907,20180910,305.61,";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(csvContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_DATE_RANGE.getError());
		this.fileValidationService.validateDEOFile(this.file, "501002000000");
	}

	@Test
	public void validateDeoFileShouldPassIfFileIsCSVAndHasCorrectData() throws IOException {
		// Given
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_CSV);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String from = LocalDate.now().minusDays(20).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		final String to = LocalDate.now().plusDays(20).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		final String csvContents = "Comp,PAYE,ERN,Payfrom,Payto,Total,\n" + "AA Insurance,9016693624A,501002000000,"
				+ from + "," + to + ",305.61,";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(csvContents.getBytes()));

		// When
		final boolean isValid = this.fileValidationService.validateDEOFile(this.file, "501002000000");

		// Then
		assertTrue("DEO file should be valid", isValid);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsXMLAndIsEmpty() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_XML);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String xmlContents = "";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(xmlContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_FORMAT.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsXMLAndHasIncorrectERN() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_XML);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String xmlContents = "<bons0:DEOSchedule xmlns:bons0=\"http://www.childmaintenance.gsi.gov.uk/futurescheme/bo/CMECDEOSchedule\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
				+ "    <CompanyLevelInfo>\n" + "       <EmployerName>CMG TEST FOundation TRUST</EmployerName>\n"
				+ "       <EmpPAYERef>9016693822A</EmpPAYERef>\n"
				+ "       <EmployerRefNum>501001820636</EmployerRefNum>\n"
				+ "       <PaymentFromDte>20190806</PaymentFromDte>\n"
				+ "       <PaymentToDte>20190905</PaymentToDte>\n"
				+ "       <TotalAmountPaid>196.86</TotalAmountPaid>\n" + "    </CompanyLevelInfo>\n"
				+ "    <EmployeeLevelInformation>\n" + "       <Forename>Testxmlupload</Forename>\n"
				+ "       <Surname>Testupload</Surname>\n" + "       <NINO>AA200104B</NINO>\n"
				+ "       <MonthlyAmtDue>196.86</MonthlyAmtDue>\n" + "       <AmountPaid>196.86</AmountPaid>\n"
				+ "    </EmployeeLevelInformation>\n" + "</bons0:DEOSchedule>";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(xmlContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_ERN.getError());
		this.fileValidationService.validateDEOFile(this.file, INVALID_ERN);
	}

	@Test
	public void validateDeoFileShouldFailIfFileIsXMLAndHasIncorrectDateRange() throws IOException {
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_XML);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String xmlContents = "<bons0:DEOSchedule xmlns:bons0=\"http://www.childmaintenance.gsi.gov.uk/futurescheme/bo/CMECDEOSchedule\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
				+ "    <CompanyLevelInfo>\n" + "       <EmployerName>CMG TEST FOundation TRUST</EmployerName>\n"
				+ "       <EmpPAYERef>9016693822A</EmpPAYERef>\n"
				+ "       <EmployerRefNum>501001820636</EmployerRefNum>\n"
				+ "       <PaymentFromDte>20180806</PaymentFromDte>\n"
				+ "       <PaymentToDte>20180905</PaymentToDte>\n"
				+ "       <TotalAmountPaid>196.86</TotalAmountPaid>\n" + "    </CompanyLevelInfo>\n"
				+ "    <EmployeeLevelInformation>\n" + "       <Forename>Testxmlupload</Forename>\n"
				+ "       <Surname>Testupload</Surname>\n" + "       <NINO>AA200104B</NINO>\n"
				+ "       <MonthlyAmtDue>196.86</MonthlyAmtDue>\n" + "       <AmountPaid>196.86</AmountPaid>\n"
				+ "    </EmployeeLevelInformation>\n" + "</bons0:DEOSchedule>";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(xmlContents.getBytes()));
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.INVALID_DATE_RANGE.getError());
		this.fileValidationService.validateDEOFile(this.file, "501001820636");
	}

	@Test
	public void validateDeoFileShouldPassIfFileIsXMLAndHasCorrectData() throws IOException {
		// Given
		given(this.file.getOriginalFilename()).willReturn(VALID_DEO_FILENAME_XML);
		given(this.file.getSize()).willReturn(100L);
		given(this.fileProperties.getDeo()).willReturn(this.fileDetails);
		given(this.fileProperties.getDeo().getSize()).willReturn(500L);
		given(this.fileProperties.getDeo().getLocation()).willReturn(this.tempFolder.getRoot().getPath());
		final String from = LocalDate.now().minusDays(20).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		final String to = LocalDate.now().plusDays(20).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		final String xmlContents = "<bons0:DEOSchedule xmlns:bons0=\"http://www.childmaintenance.gsi.gov.uk/futurescheme/bo/CMECDEOSchedule\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
				+ "    <CompanyLevelInfo>\n" + "       <EmployerName>CMG TEST FOundation TRUST</EmployerName>\n"
				+ "       <EmpPAYERef>9016693822A</EmpPAYERef>\n"
				+ "       <EmployerRefNum>501001820636</EmployerRefNum>\n" + "       <PaymentFromDte>" + from
				+ "</PaymentFromDte>\n" + "       <PaymentToDte>" + to + "</PaymentToDte>\n"
				+ "       <TotalAmountPaid>196.86</TotalAmountPaid>\n" + "    </CompanyLevelInfo>\n"
				+ "    <EmployeeLevelInformation>\n" + "       <Forename>Testxmlupload</Forename>\n"
				+ "       <Surname>Testupload</Surname>\n" + "       <NINO>AA200104B</NINO>\n"
				+ "       <MonthlyAmtDue>196.86</MonthlyAmtDue>\n" + "       <AmountPaid>196.86</AmountPaid>\n"
				+ "    </EmployeeLevelInformation>\n" + "</bons0:DEOSchedule>";
		given(this.file.getInputStream()).willReturn(new ByteArrayInputStream(xmlContents.getBytes()));

		// When
		final boolean isValid = this.fileValidationService.validateDEOFile(this.file, "501001820636");

		// Then
		assertTrue("DEO file should be valid", isValid);
	}

	@Test
	public void validateFileNamesShouldFailForDuplicateFileNames() {
		final List<String> fileNames = Arrays.asList("file1", "file2", "file1");
		expectedException.expect(BadRequestException.class);
		expectedException.expectMessage(ErrorEnum.DUPLICATE_FILE.getError());
		this.fileValidationService.validateDuplicateFileNames(fileNames);
	}

	@Test
	public void validateFileNamesShouldPassForDuplicateFileNames() {
		// Given
		final List<String> fileNames = Arrays.asList("file1", "file2");

		// When
		final boolean duplicate = this.fileValidationService.validateDuplicateFileNames(fileNames);

		// Then
		assertFalse("Duplicate should not be found", duplicate);
	}
}
