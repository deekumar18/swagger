package com.hendisantika.springbootrestswaggerexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestSwaggerExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestSwaggerExampleApplication.class, args);
	}
}
